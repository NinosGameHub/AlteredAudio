/* @ds-bundle: {"format":3,"namespace":"AlteredAudioDesignSystem_3ace71","components":[{"name":"Button","sourcePath":"components/controls/Button.jsx"},{"name":"Knob","sourcePath":"components/controls/Knob.jsx"},{"name":"Select","sourcePath":"components/controls/Select.jsx"},{"name":"ToggleSwitch","sourcePath":"components/controls/ToggleSwitch.jsx"},{"name":"CRTDisplay","sourcePath":"components/displays/CRTDisplay.jsx"},{"name":"EQCurve","sourcePath":"components/displays/EQCurve.jsx"},{"name":"Meter","sourcePath":"components/displays/Meter.jsx"},{"name":"ModMatrix","sourcePath":"components/displays/ModMatrix.jsx"},{"name":"Badge","sourcePath":"components/surfaces/Badge.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"ModuleTile","sourcePath":"components/surfaces/ModuleTile.jsx"}],"sourceHashes":{"components/controls/Button.jsx":"450e3cde3e37","components/controls/Knob.jsx":"b22ed0aea817","components/controls/Select.jsx":"f4d895ab5d02","components/controls/ToggleSwitch.jsx":"298f4160e519","components/displays/CRTDisplay.jsx":"e83e5623bb35","components/displays/EQCurve.jsx":"c59cb9b8c86d","components/displays/Meter.jsx":"0574cd06dbe6","components/displays/ModMatrix.jsx":"359663d820d2","components/surfaces/Badge.jsx":"6240779f16d4","components/surfaces/Card.jsx":"809597536961","components/surfaces/ModuleTile.jsx":"2c00baa9efa7"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AlteredAudioDesignSystem_3ace71 = window.AlteredAudioDesignSystem_3ace71 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/controls/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — Altered Audio text button.
 * variant: "primary" (filled Apple blue, white text), "secondary"
 * (sunken grey fill — mirrors the native TextButton), "ghost"
 * (transparent, accent text). Rounded 6px; Apple-style pill via `pill`.
 */
function Button({
  children,
  variant = "secondary",
  size = "md",
  pill = false,
  disabled = false,
  iconLeft,
  onClick,
  className = "",
  ...rest
}) {
  const sizes = {
    sm: {
      h: 28,
      px: 12,
      fs: "var(--fs-11)"
    },
    md: {
      h: 34,
      px: 16,
      fs: "var(--fs-13)"
    },
    lg: {
      h: 44,
      px: 22,
      fs: "var(--fs-15)"
    }
  };
  const s = sizes[size] || sizes.md;
  const variants = {
    primary: {
      background: "var(--accent-primary)",
      color: "var(--text-on-accent)",
      border: "1px solid transparent"
    },
    secondary: {
      background: "var(--surface-sunken)",
      color: "var(--text-body)",
      border: "var(--border-hairline)"
    },
    ghost: {
      background: "transparent",
      color: "var(--accent-primary)",
      border: "1px solid transparent"
    }
  };
  const v = variants[variant] || variants.secondary;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: `aa-button aa-button--${variant} ${className}`,
    disabled: disabled,
    onClick: onClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "6px",
      height: `${s.h}px`,
      padding: `0 ${s.px}px`,
      fontFamily: "var(--font-system)",
      fontSize: s.fs,
      fontWeight: "var(--fw-medium)",
      lineHeight: 1,
      borderRadius: pill ? "var(--radius-pill)" : "var(--radius-sm)",
      cursor: disabled ? "default" : "pointer",
      opacity: disabled ? 0.45 : 1,
      transition: "background var(--dur-fast) var(--ease-standard), opacity var(--dur-fast)",
      ...v
    }
  }, rest), iconLeft ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    },
    "aria-hidden": "true"
  }, iconLeft) : null, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/Button.jsx", error: String((e && e.message) || e) }); }

// components/controls/Knob.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Knob — Altered Audio's flat Braun/Moog-style rotary control.
 * Mirrors AaLookAndFeel::drawRotarySlider: a flat dirty-cream disc with a
 * 1px warm outline, a near-black indicator line from ~0.2r to ~0.86r, and
 * two range-marker dots at the 7-o'clock start and 5-o'clock end angles.
 * Optional accent ring shows the value sweep in the module's category color.
 */
function Knob({
  value = 0,
  min = 0,
  max = 1,
  size = 64,
  label,
  display,
  accent = "var(--accent-primary)",
  showArc = false,
  mods = [],
  disabled = false,
  onChange,
  className = "",
  ...rest
}) {
  const START = -135; // 7 o'clock
  const END = 135; // 5 o'clock
  const t = Math.max(0, Math.min(1, (value - min) / (max - min || 1)));
  const angleAt = frac => START + frac * (END - START);
  const cx = size / 2;
  const cy = size / 2;
  const r = size * 0.4; // disc radius
  const dotR = r + 5.5; // range dots sit just outside the disc

  const pt = (deg, radius) => {
    const a = deg * Math.PI / 180;
    return [cx + radius * Math.sin(a), cy - radius * Math.cos(a)];
  };
  const arc = (a0, a1, radius) => {
    const [x0, y0] = pt(a0, radius);
    const [x1, y1] = pt(a1, radius);
    const large = a1 - a0 > 180 ? 1 : 0;
    return `M ${x0} ${y0} A ${radius} ${radius} 0 ${large} 1 ${x1} ${y1}`;
  };
  const ang = angleAt(t);
  const [lx0, ly0] = pt(ang, r * 0.2);
  const [lx1, ly1] = pt(ang, r * 0.86);
  const [d0x, d0y] = pt(START, dotR);
  const [d1x, d1y] = pt(END, dotR);
  const lineColor = disabled ? "var(--text-disabled)" : "var(--knob-line)";
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `aa-knob ${className}`,
    "data-disabled": disabled || undefined,
    style: {
      display: "inline-flex",
      flexDirection: "column",
      alignItems: "center",
      gap: "5px",
      opacity: disabled ? 0.45 : 1,
      userSelect: "none"
    }
  }, rest), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--fs-10)",
      fontWeight: "var(--fw-semibold)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, label) : null, /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: `0 0 ${size} ${size}`,
    role: "slider",
    "aria-valuenow": value,
    "aria-valuemin": min,
    "aria-valuemax": max,
    style: {
      display: "block",
      cursor: disabled ? "default" : "ns-resize"
    },
    onClick: () => !disabled && onChange && onChange(value)
  }, showArc ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: arc(START, END, dotR),
    fill: "none",
    stroke: "var(--border-default)",
    strokeWidth: "2",
    strokeLinecap: "round"
  }), !disabled && t > 0.001 ? /*#__PURE__*/React.createElement("path", {
    d: arc(START, ang, dotR),
    fill: "none",
    stroke: accent,
    strokeWidth: "2",
    strokeLinecap: "round"
  }) : null) : null, /*#__PURE__*/React.createElement("circle", {
    cx: d0x,
    cy: d0y,
    r: "1.5",
    fill: "var(--knob-dot)"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: d1x,
    cy: d1y,
    r: "1.5",
    fill: "var(--knob-dot)"
  }), !disabled && mods && mods.length ? mods.map((md, i) => {
    const depth = Math.max(-1, Math.min(1, md.depth || 0));
    if (Math.abs(depth) < 0.001) return null;
    const modR = dotR + 3 + i * 3;
    const tEnd = Math.max(0, Math.min(1, t + depth));
    const a0 = depth >= 0 ? ang : angleAt(tEnd);
    const a1 = depth >= 0 ? angleAt(tEnd) : ang;
    const [ex, ey] = pt(angleAt(tEnd), modR);
    return /*#__PURE__*/React.createElement("g", {
      key: i
    }, /*#__PURE__*/React.createElement("path", {
      d: arc(a0, a1, modR),
      fill: "none",
      stroke: md.color || "var(--cat-modulation)",
      strokeWidth: "1.6",
      strokeLinecap: "round",
      opacity: "0.95"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: ex,
      cy: ey,
      r: "1.6",
      fill: md.color || "var(--cat-modulation)"
    }));
  }) : null, /*#__PURE__*/React.createElement("circle", {
    cx: cx,
    cy: cy,
    r: r,
    fill: "var(--knob-body)",
    stroke: "var(--border-default)",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("line", {
    x1: lx0,
    y1: ly0,
    x2: lx1,
    y2: ly1,
    stroke: lineColor,
    strokeWidth: "2.5",
    strokeLinecap: "round"
  })), display != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--fs-10)",
      color: "var(--text-muted)",
      lineHeight: 1
    }
  }, display) : null);
}
Object.assign(__ds_scope, { Knob });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/Knob.jsx", error: String((e && e.message) || e) }); }

// components/controls/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Select — flat combo box from AaLookAndFeel::drawComboBox.
 * White fill, 6px radius, hairline border, a 1.5px chevron in secondary
 * grey at the right. Optional uppercase label above.
 */
function Select({
  value,
  onChange,
  options = [],
  label,
  disabled = false,
  className = "",
  ...rest
}) {
  const opts = options.map(o => typeof o === "string" ? {
    value: o,
    label: o
  } : o);
  return /*#__PURE__*/React.createElement("div", {
    className: `aa-select ${className}`,
    style: {
      display: "inline-flex",
      flexDirection: "column",
      gap: "4px"
    }
  }, label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--fs-10)",
      fontWeight: "var(--fw-semibold)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "inline-block"
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    value: value,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.value),
    style: {
      appearance: "none",
      WebkitAppearance: "none",
      MozAppearance: "none",
      width: "100%",
      height: "var(--h-control)",
      padding: "0 28px 0 10px",
      fontFamily: "var(--font-system)",
      fontSize: "var(--fs-13)",
      color: "var(--text-body)",
      background: "var(--surface-card)",
      border: "var(--border-hairline)",
      borderRadius: "var(--radius-sm)",
      cursor: disabled ? "default" : "pointer",
      opacity: disabled ? 0.5 : 1,
      outline: "none"
    }
  }, rest), opts.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement("svg", {
    width: "10",
    height: "10",
    viewBox: "0 0 10 10",
    "aria-hidden": "true",
    style: {
      position: "absolute",
      right: "10px",
      top: "50%",
      transform: "translateY(-50%)",
      pointerEvents: "none"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1 3.5 L5 7 L9 3.5",
    fill: "none",
    stroke: "var(--text-muted)",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/Select.jsx", error: String((e && e.message) || e) }); }

// components/controls/ToggleSwitch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ToggleSwitch — iOS-style pill switch from AaLookAndFeel::drawToggleButton.
 * 32×18 track, green when on / hairline grey when off, white thumb that
 * slides. Optional trailing label (e.g. "Active", "Ping-Pong", "Auto Gain").
 */
function ToggleSwitch({
  checked = false,
  onChange,
  label,
  disabled = false,
  className = "",
  ...rest
}) {
  const W = 32;
  const H = 18;
  const pad = 2;
  const thumb = H - 4;
  return /*#__PURE__*/React.createElement("label", _extends({
    className: `aa-toggle ${className}`,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "8px",
      cursor: disabled ? "default" : "pointer",
      opacity: disabled ? 0.5 : 1,
      userSelect: "none"
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    role: "switch",
    "aria-checked": checked,
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      position: "relative",
      flex: "0 0 auto",
      width: `${W}px`,
      height: `${H}px`,
      borderRadius: "var(--radius-pill)",
      background: checked ? "var(--state-active)" : "var(--aa-surface-alt)",
      border: checked ? "1px solid var(--state-active)" : "1px solid var(--border-default)",
      transition: "background var(--dur-normal) var(--ease-standard), border-color var(--dur-normal)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: `${pad}px`,
      left: checked ? `${W - thumb - pad}px` : `${pad}px`,
      width: `${thumb}px`,
      height: `${thumb}px`,
      borderRadius: "var(--radius-pill)",
      background: "var(--surface-card)",
      transition: "left var(--dur-normal) var(--ease-standard)"
    }
  })), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--fs-11)",
      color: "var(--text-body)"
    }
  }, label) : null);
}
Object.assign(__ds_scope, { ToggleSwitch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/ToggleSwitch.jsx", error: String((e && e.message) || e) }); }

// components/displays/CRTDisplay.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * CRTDisplay — the amber phosphor spectrum strip (CRTDisplay.cpp), sci-fi
 * treatment. Canvas-rendered: a single glowing spectral line with a soft
 * gradient fill beneath it, a sweeping scan highlight, a perspective grid
 * and a vignette. Amber-on-near-black. Feed `bars` (0..1) or let it animate.
 */
function CRTDisplay({
  bars,
  live = true,
  height = 180,
  label,
  bins = 56,
  className = "",
  ...rest
}) {
  const wrapRef = React.useRef(null);
  const canvasRef = React.useRef(null);
  const peaks = React.useRef(new Float32Array(bins));
  const data = React.useRef(new Float32Array(bins));
  const barsRef = React.useRef(bars);
  barsRef.current = bars;
  React.useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    let raf,
      t = 0,
      sweep = -0.2,
      running = true;
    const AMBER = [228, 162, 16];
    const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
    const synth = (i, n) => {
      const f = i / n;
      const tilt = Math.pow(1 - f, 0.8);
      // a few drifting spectral peaks for life
      const p1 = Math.exp(-Math.pow((f - (0.12 + 0.03 * Math.sin(t * 0.7))) / 0.05, 2));
      const p2 = Math.exp(-Math.pow((f - (0.34 + 0.05 * Math.sin(t * 0.5 + 1))) / 0.07, 2));
      const p3 = Math.exp(-Math.pow((f - (0.62 + 0.04 * Math.sin(t * 0.9 + 2))) / 0.09, 2));
      const wob = 0.5 + 0.5 * Math.sin(t * 2.0 + i * 0.6) * Math.cos(t * 1.1 + i * 0.25);
      let v = 0.16 + tilt * 0.5 * wob + 0.55 * p1 + 0.4 * p2 + 0.3 * p3;
      return Math.max(0.04, Math.min(1, v));
    };
    const draw = () => {
      if (!running) return;
      const cssW = wrap.clientWidth || 600;
      const cssH = height;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      if (canvas.width !== Math.round(cssW * dpr) || canvas.height !== Math.round(cssH * dpr)) {
        canvas.width = Math.round(cssW * dpr);
        canvas.height = Math.round(cssH * dpr);
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const W = cssW,
        H = cssH;
      const n = bins;

      // advance source data
      const ext = barsRef.current;
      for (let i = 0; i < n; i++) {
        const target = ext ? ext[Math.floor(i / n * ext.length)] || 0 : live ? synth(i, n) : 0.0;
        // attack fast, release slow
        const cur = data.current[i];
        data.current[i] = target > cur ? cur + (target - cur) * 0.5 : cur + (target - cur) * 0.12;
        peaks.current[i] = Math.max(peaks.current[i] * 0.965, data.current[i]);
      }
      ctx.clearRect(0, 0, W, H);

      // background glass + radial vignette
      const bg = ctx.createRadialGradient(W / 2, H * 0.55, H * 0.2, W / 2, H * 0.55, W * 0.7);
      bg.addColorStop(0, "#0b0907");
      bg.addColorStop(1, "#040302");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);
      const padX = 12,
        padTop = 16,
        padBot = 22;
      const plotW = W - padX * 2;
      const baseY = H - padBot;
      const maxH = baseY - padTop;

      // perspective-ish grid
      ctx.lineWidth = 1;
      ctx.strokeStyle = rgba(AMBER, 0.07);
      for (let g = 0; g <= 4; g++) {
        const yy = padTop + g / 4 * maxH;
        ctx.beginPath();
        ctx.moveTo(padX, yy);
        ctx.lineTo(W - padX, yy);
        ctx.stroke();
      }
      const fxs = [0.0, 0.16, 0.34, 0.5, 0.68, 0.84, 1.0];
      fxs.forEach(fx => {
        const xx = padX + fx * plotW;
        ctx.beginPath();
        ctx.moveTo(xx, padTop);
        ctx.lineTo(xx, baseY);
        ctx.stroke();
      });
      // baseline
      ctx.strokeStyle = rgba(AMBER, 0.35);
      ctx.beginPath();
      ctx.moveTo(padX, baseY);
      ctx.lineTo(W - padX, baseY);
      ctx.stroke();
      const linePts = [];
      for (let i = 0; i < n; i++) {
        const h = data.current[i] * maxH;
        const x = padX + (i + 0.5) * (plotW / n);
        linePts.push([x, baseY - h]);
      }
      // clamp ends to the plot edges
      linePts.unshift([padX, linePts[0][1]]);
      linePts.push([W - padX, linePts[linePts.length - 1][1]]);

      // smooth path through the points (midpoint quadratics)
      const tracePath = () => {
        ctx.beginPath();
        ctx.moveTo(linePts[0][0], linePts[0][1]);
        for (let i = 1; i < linePts.length - 1; i++) {
          const mx = (linePts[i][0] + linePts[i + 1][0]) / 2;
          const my = (linePts[i][1] + linePts[i + 1][1]) / 2;
          ctx.quadraticCurveTo(linePts[i][0], linePts[i][1], mx, my);
        }
        const last = linePts[linePts.length - 1];
        ctx.lineTo(last[0], last[1]);
      };

      // soft gradient fill under the line
      tracePath();
      ctx.lineTo(W - padX, baseY);
      ctx.lineTo(padX, baseY);
      ctx.closePath();
      const fillG = ctx.createLinearGradient(0, padTop, 0, baseY);
      fillG.addColorStop(0, rgba(AMBER, 0.28));
      fillG.addColorStop(1, rgba(AMBER, 0));
      ctx.fillStyle = fillG;
      ctx.fill();

      // glowing spectral line
      tracePath();
      ctx.strokeStyle = "rgba(255,236,180,0.95)";
      ctx.lineWidth = 1.8;
      ctx.shadowBlur = 14;
      ctx.shadowColor = rgba(AMBER, 0.95);
      ctx.stroke();
      // second pass for a brighter core glow
      ctx.shadowBlur = 6;
      ctx.shadowColor = "rgba(255,240,200,0.9)";
      ctx.stroke();
      ctx.shadowBlur = 0;

      // sweeping scan highlight
      sweep += 0.004;
      if (sweep > 1.25) sweep = -0.25;
      const sx = padX + sweep * plotW;
      const sw = ctx.createLinearGradient(sx - 40, 0, sx + 40, 0);
      sw.addColorStop(0, rgba(AMBER, 0));
      sw.addColorStop(0.5, rgba(AMBER, 0.10));
      sw.addColorStop(1, rgba(AMBER, 0));
      ctx.fillStyle = sw;
      ctx.fillRect(sx - 40, padTop, 80, maxH);
      // bright sweep edge
      ctx.fillStyle = "rgba(255,240,200,0.10)";
      ctx.fillRect(sx, padTop, 1, maxH);
      t += 0.05;
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => {
      running = false;
      cancelAnimationFrame(raf);
    };
  }, [live, height, bins]);
  const freqLabels = ["20", "100", "500", "1k", "5k", "20k"];
  return /*#__PURE__*/React.createElement("div", _extends({
    ref: wrapRef,
    className: `aa-crt ${className}`,
    style: {
      position: "relative",
      width: "100%",
      height: `${height}px`,
      background: "var(--crt-bg)",
      overflow: "hidden"
    }
  }, rest), /*#__PURE__*/React.createElement("canvas", {
    ref: canvasRef,
    style: {
      display: "block",
      width: "100%",
      height: "100%"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      pointerEvents: "none",
      backgroundImage: "repeating-linear-gradient(to bottom, transparent 0, transparent 2px, var(--crt-scanline) 2px, var(--crt-scanline) 3px)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      pointerEvents: "none",
      boxShadow: "inset 0 0 60px rgba(0,0,0,0.7), inset 0 0 14px rgba(228,162,16,0.10)"
    }
  }), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 8,
      left: 12,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--fs-9)",
      letterSpacing: "0.12em",
      color: "var(--crt-amber)",
      textShadow: "0 0 8px rgba(228,162,16,0.7)",
      opacity: 0.9
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 12,
      right: 12,
      bottom: 4,
      display: "flex",
      justifyContent: "space-between",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--fs-9)",
      color: "var(--crt-amber)",
      opacity: 0.55
    }
  }, freqLabels.map(f => /*#__PURE__*/React.createElement("span", {
    key: f
  }, f))));
}
Object.assign(__ds_scope, { CRTDisplay });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/displays/CRTDisplay.jsx", error: String((e && e.message) || e) }); }

// components/displays/EQCurve.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * EQCurve — the EQ module's frequency-response display (backlog item #2).
 * Near-black CRT glass with a log-frequency grid, a faint amber spectrum
 * behind, the summed EQ response curve drawn in Filter/EQ blue, and one
 * draggable handle per band. Drag a handle horizontally to move FREQ,
 * vertically to move GAIN. Cosmetic — drives the `bands` you pass in.
 *
 * Band: { freq (Hz 20..20000), gain (dB -18..18), q, type, on, color? }
 */
function EQCurve({
  bands = [],
  onChange,
  width = 560,
  height = 220,
  showSpectrum = true,
  accent = "var(--cat-filtereq)",
  className = "",
  ...rest
}) {
  const padL = 8,
    padR = 8,
    padT = 10,
    padB = 18;
  const W = width,
    H = height;
  const plotW = W - padL - padR;
  const plotH = H - padT - padB;
  const FMIN = 20,
    FMAX = 20000;
  const GMAX = 18;
  const logF = f => Math.log10(f);
  const x = f => padL + (logF(f) - logF(FMIN)) / (logF(FMAX) - logF(FMIN)) * plotW;
  const y = g => padT + (1 - (g + GMAX) / (2 * GMAX)) * plotH;
  const invX = px => Math.pow(10, logF(FMIN) + (px - padL) / plotW * (logF(FMAX) - logF(FMIN)));
  const invY = py => (1 - (py - padT) / plotH) * 2 * GMAX - GMAX;

  // peaking/shelf gaussian-ish bump model for the summed curve
  const bandGain = (b, f) => {
    if (!b.on) return 0;
    const oct = Math.log2(f / b.freq);
    const bw = 1 / Math.max(0.3, b.q || 1);
    if (b.type === "LowShelf") return b.gain / (1 + Math.pow(Math.max(0.0001, f / b.freq), 2.2));
    if (b.type === "HighShelf") return b.gain / (1 + Math.pow(Math.max(0.0001, b.freq / f), 2.2));
    return b.gain * Math.exp(-(oct * oct) / (2 * bw * bw));
  };
  const N = 120;
  const pts = [];
  for (let i = 0; i <= N; i++) {
    const f = Math.pow(10, logF(FMIN) + i / N * (logF(FMAX) - logF(FMIN)));
    let g = 0;
    bands.forEach(b => g += bandGain(b, f));
    pts.push([x(f), y(Math.max(-GMAX, Math.min(GMAX, g)))]);
  }
  const curve = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
  const fill = curve + ` L ${x(FMAX).toFixed(1)} ${y(0).toFixed(1)} L ${x(FMIN).toFixed(1)} ${y(0).toFixed(1)} Z`;

  // fake spectrum behind
  const spec = [];
  if (showSpectrum) {
    for (let i = 0; i < 48; i++) {
      const f = Math.pow(10, logF(FMIN) + i / 47 * (logF(FMAX) - logF(FMIN)));
      const tilt = 1 - i / 48;
      const h = Math.max(0.05, 0.2 + tilt * 0.55 + 0.12 * Math.sin(i * 1.3));
      spec.push([x(f), h]);
    }
  }
  const drag = React.useRef(null);
  const svgRef = React.useRef(null);
  const onDown = i => e => {
    drag.current = i;
    e.preventDefault();
  };
  React.useEffect(() => {
    const move = e => {
      if (drag.current == null || !onChange || !svgRef.current) return;
      const r = svgRef.current.getBoundingClientRect();
      const cx = (e.clientX - r.left) / r.width * W;
      const cy = (e.clientY - r.top) / r.height * H;
      const f = Math.max(FMIN, Math.min(FMAX, invX(cx)));
      const g = Math.max(-GMAX, Math.min(GMAX, invY(cy)));
      const next = bands.map((b, idx) => idx === drag.current ? {
        ...b,
        freq: Math.round(f),
        gain: +g.toFixed(1),
        on: true
      } : b);
      onChange(next);
    };
    const up = () => drag.current = null;
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
    };
  }, [bands, onChange]);
  const gridF = [20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000];
  const labF = {
    20: "20",
    100: "100",
    1000: "1k",
    10000: "10k",
    20000: "20k"
  };
  const gridG = [-12, -6, 0, 6, 12];
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `aa-eqcurve ${className}`,
    style: {
      position: "relative",
      width: W,
      maxWidth: "100%"
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    ref: svgRef,
    width: "100%",
    viewBox: `0 0 ${W} ${H}`,
    style: {
      display: "block",
      background: "var(--crt-bg)",
      borderRadius: "var(--radius-sm)"
    }
  }, gridF.map(f => /*#__PURE__*/React.createElement("line", {
    key: f,
    x1: x(f),
    y1: padT,
    x2: x(f),
    y2: padT + plotH,
    stroke: "var(--crt-grid)",
    strokeWidth: "1"
  })), gridG.map(g => /*#__PURE__*/React.createElement("line", {
    key: g,
    x1: padL,
    y1: y(g),
    x2: padL + plotW,
    y2: y(g),
    stroke: g === 0 ? "rgba(228,162,16,0.32)" : "var(--crt-grid)",
    strokeWidth: g === 0 ? 1.2 : 1
  })), showSpectrum && spec.map((s, i) => /*#__PURE__*/React.createElement("rect", {
    key: i,
    x: s[0] - 4,
    y: padT + plotH - s[1] * plotH,
    width: "6",
    height: s[1] * plotH,
    fill: "var(--crt-amber)",
    opacity: "0.16"
  })), /*#__PURE__*/React.createElement("path", {
    d: fill,
    fill: accent,
    opacity: "0.14"
  }), /*#__PURE__*/React.createElement("path", {
    d: curve,
    fill: "none",
    stroke: accent,
    strokeWidth: "2",
    strokeLinejoin: "round"
  }), bands.map((b, i) => /*#__PURE__*/React.createElement("g", {
    key: i,
    style: {
      cursor: onChange ? "grab" : "default"
    },
    onMouseDown: onDown(i)
  }, /*#__PURE__*/React.createElement("circle", {
    cx: x(b.freq),
    cy: y(b.on ? b.gain : 0),
    r: "7",
    fill: b.on ? b.color || accent : "var(--state-inactive)",
    opacity: b.on ? 0.9 : 0.5,
    stroke: "var(--crt-bg)",
    strokeWidth: "1.5"
  }), /*#__PURE__*/React.createElement("text", {
    x: x(b.freq),
    y: y(b.on ? b.gain : 0) + 3.2,
    textAnchor: "middle",
    fontFamily: "var(--font-mono)",
    fontSize: "8",
    fill: "#fff",
    style: {
      pointerEvents: "none"
    }
  }, i + 1))), gridF.filter(f => labF[f]).map(f => /*#__PURE__*/React.createElement("text", {
    key: f,
    x: x(f),
    y: H - 5,
    textAnchor: "middle",
    fontFamily: "var(--font-mono)",
    fontSize: "9",
    fill: "var(--crt-amber)",
    opacity: "0.6"
  }, labF[f]))));
}
Object.assign(__ds_scope, { EQCurve });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/displays/EQCurve.jsx", error: String((e && e.message) || e) }); }

// components/displays/Meter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Meter — a thin segmented level meter for I/O and gain-reduction readouts
 * (the header I-O meters and the comp/limiter GR meters in the todo).
 * Vertical or horizontal. For levels, fill rises green→amber→orange toward
 * the top; for gain reduction (`mode="gr"`) it fills downward in the
 * dynamics burnt-orange.
 */
function Meter({
  value = 0,
  // 0..1
  mode = "level",
  // "level" | "gr"
  orientation = "vertical",
  segments = 16,
  length = 80,
  thickness = 6,
  label,
  className = "",
  ...rest
}) {
  const v = Math.max(0, Math.min(1, value));
  const horizontal = orientation === "horizontal";
  const segColor = i => {
    const frac = (i + 1) / segments;
    if (mode === "gr") return "var(--cat-dynamics)";
    if (frac > 0.92) return "var(--cat-dynamics)";
    if (frac > 0.78) return "var(--crt-amber)";
    return "var(--state-active)";
  };

  // for GR the meter lights from the top downward
  const lit = i => {
    const frac = (i + 1) / segments;
    return mode === "gr" ? frac > 1 - v : frac <= v;
  };
  const segs = Array.from({
    length: segments
  }, (_, i) => {
    // visual order: bottom→top for vertical level; render reversed
    const idx = horizontal ? i : segments - 1 - i;
    return /*#__PURE__*/React.createElement("span", {
      key: idx,
      style: {
        flex: 1,
        background: lit(idx) ? segColor(idx) : "var(--aa-surface-alt)",
        borderRadius: "1px",
        opacity: lit(idx) ? 1 : 0.6,
        transition: "background var(--dur-fast) linear"
      }
    });
  });
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `aa-meter aa-meter--${mode} ${className}`,
    style: {
      display: "inline-flex",
      flexDirection: "column",
      alignItems: "center",
      gap: "4px"
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: horizontal ? "row" : "column",
      gap: "2px",
      width: horizontal ? `${length}px` : `${thickness}px`,
      height: horizontal ? `${thickness}px` : `${length}px`,
      padding: "2px",
      background: "var(--crt-bg)",
      borderRadius: "var(--radius-xs)"
    }
  }, segs), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--fs-9)",
      fontFamily: "var(--font-mono)",
      color: "var(--text-muted)",
      letterSpacing: "0.04em"
    }
  }, label) : null);
}
Object.assign(__ds_scope, { Meter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/displays/Meter.jsx", error: String((e && e.message) || e) }); }

// components/displays/ModMatrix.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ModMatrix — the modulation routing grid (backlog item #5).
 * Rows are mod sources (LFOs, envelopes, macros), columns are destination
 * parameters. Each cell shows a bipolar depth (-1..+1) as a center-anchored
 * bar — positive in the source's color, negative in warm-grey. Click-drag a
 * cell vertically to set depth; click the center to clear. Cosmetic: drives
 * the `values` map you pass in (keyed "<sourceId>:<destId>").
 */
function ModMatrix({
  sources = [],
  destinations = [],
  values = {},
  onChange,
  cell = 38,
  className = "",
  ...rest
}) {
  const key = (s, d) => `${s}:${d}`;
  const drag = React.useRef(null);
  const onDown = (s, d) => e => {
    drag.current = {
      s,
      d,
      startY: e.clientY,
      start: values[key(s, d)] || 0
    };
    e.preventDefault();
  };
  React.useEffect(() => {
    const move = e => {
      const g = drag.current;
      if (!g || !onChange) return;
      const dv = (g.startY - e.clientY) / 80; // 80px = full range
      const v = Math.max(-1, Math.min(1, g.start + dv));
      onChange({
        ...values,
        [key(g.s, g.d)]: +v.toFixed(2)
      });
    };
    const up = () => drag.current = null;
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
    };
  }, [values, onChange]);
  const clearCell = (s, d) => e => {
    if (!onChange) return;
    e.stopPropagation();
    const next = {
      ...values
    };
    delete next[key(s, d)];
    onChange(next);
  };
  const labelW = 96;
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `aa-modmatrix ${className}`,
    style: {
      display: "inline-block",
      background: "var(--surface-card)",
      border: "var(--border-hairline)",
      borderRadius: "var(--radius-md)",
      overflow: "hidden"
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      borderBottom: "var(--border-hairline)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: labelW,
      flex: "0 0 auto",
      borderRight: "var(--border-hairline)",
      background: "var(--surface-sunken)"
    }
  }), destinations.map(d => /*#__PURE__*/React.createElement("div", {
    key: d.id,
    style: {
      width: cell,
      flex: "0 0 auto",
      height: 64,
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "center",
      paddingBottom: 6,
      borderRight: "var(--border-hairline)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      writingMode: "vertical-rl",
      transform: "rotate(180deg)",
      fontSize: "var(--fs-9)",
      fontWeight: "var(--fw-semibold)",
      letterSpacing: "0.02em",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      whiteSpace: "nowrap"
    }
  }, d.label)))), sources.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.id,
    style: {
      display: "flex",
      borderBottom: "var(--border-hairline)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: labelW,
      flex: "0 0 auto",
      height: cell,
      display: "flex",
      alignItems: "center",
      gap: 7,
      padding: "0 10px",
      borderRight: "var(--border-hairline)",
      background: "var(--surface-sunken)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 2,
      background: s.color || "var(--accent-primary)",
      flex: "0 0 auto"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--fs-10)",
      fontWeight: "var(--fw-semibold)",
      color: "var(--text-body)",
      whiteSpace: "nowrap"
    }
  }, s.label)), destinations.map(d => {
    const v = values[key(s.id, d.id)] || 0;
    const active = Math.abs(v) > 0.001;
    const col = v >= 0 ? s.color || "var(--accent-primary)" : "var(--text-muted)";
    return /*#__PURE__*/React.createElement("div", {
      key: d.id,
      onMouseDown: onDown(s.id, d.id),
      onDoubleClick: clearCell(s.id, d.id),
      title: active ? (v > 0 ? "+" : "") + Math.round(v * 100) + "%" : "drag to assign",
      style: {
        width: cell,
        height: cell,
        flex: "0 0 auto",
        position: "relative",
        borderRight: "var(--border-hairline)",
        cursor: "ns-resize",
        background: active ? "var(--surface-page)" : "transparent"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        left: 4,
        right: 4,
        top: "50%",
        height: 1,
        background: "var(--border-default)",
        opacity: 0.7
      }
    }), active ? /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        left: "50%",
        transform: "translateX(-50%)",
        width: 6,
        borderRadius: 2,
        background: col,
        height: Math.abs(v) * (cell / 2 - 3),
        top: v >= 0 ? `calc(50% - ${Math.abs(v) * (cell / 2 - 3)}px)` : "50%"
      }
    }) : /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "var(--border-default)",
        fontSize: 11,
        opacity: 0.5
      }
    }, "\xB7"));
  }))));
}
Object.assign(__ds_scope, { ModMatrix });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/displays/ModMatrix.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — small status / count pill.
 * tone: "neutral" (grey), "accent" (blue tint), "active" (green tint),
 * "muted" (sunken). Uppercase, tracked, tiny — matches the UI's label voice.
 */
function Badge({
  children,
  tone = "neutral",
  dot = false,
  className = "",
  ...rest
}) {
  const tones = {
    neutral: {
      bg: "var(--surface-sunken)",
      fg: "var(--text-muted)",
      dot: "var(--text-muted)"
    },
    accent: {
      bg: "var(--accent-tint)",
      fg: "var(--accent-press)",
      dot: "var(--accent-primary)"
    },
    active: {
      bg: "rgba(48,209,88,0.14)",
      fg: "#1B7F38",
      dot: "var(--state-active)"
    },
    muted: {
      bg: "var(--surface-sunken)",
      fg: "var(--text-disabled)",
      dot: "var(--state-inactive)"
    }
  };
  const t = tones[tone] || tones.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    className: `aa-badge aa-badge--${tone} ${className}`,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "5px",
      height: "18px",
      padding: "0 8px",
      borderRadius: "var(--radius-pill)",
      background: t.bg,
      color: t.fg,
      fontSize: "var(--fs-10)",
      fontWeight: "var(--fw-semibold)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      whiteSpace: "nowrap"
    }
  }, rest), dot ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: "6px",
      height: "6px",
      borderRadius: "var(--radius-pill)",
      background: t.dot
    }
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Badge.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — the base white surface. Hairline border, 6px radius, no shadow
 * (the native plugin is flat). `selected` applies the core interaction
 * recipe: faint-blue fill, blue border, 8px radius.
 */
function Card({
  children,
  selected = false,
  header,
  padding = "var(--space-4)",
  onClick,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `aa-card ${selected ? "is-selected" : ""} ${className}`,
    onClick: onClick,
    style: {
      background: selected ? "var(--surface-selected)" : "var(--surface-card)",
      border: selected ? "1px solid var(--accent-primary)" : "var(--border-hairline)",
      borderRadius: selected ? "var(--radius-md)" : "var(--radius-sm)",
      overflow: "hidden",
      cursor: onClick ? "pointer" : "default",
      transition: "background var(--dur-normal) var(--ease-standard), border-color var(--dur-normal)",
      ...rest.style
    }
  }, rest), header ? /*#__PURE__*/React.createElement("div", {
    style: {
      height: "var(--h-panel-header)",
      display: "flex",
      alignItems: "center",
      padding: "0 var(--space-4)",
      borderBottom: "var(--border-hairline)",
      background: "var(--surface-card)",
      fontSize: "var(--fs-15)",
      fontWeight: "var(--fw-bold)",
      color: "var(--text-body)",
      letterSpacing: "var(--tracking-label)"
    }
  }, header) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding
    }
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/ModuleTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ModuleTile — one row in the plugin's left tile list (ModuleTileList).
 * A ~40px row with an always-visible 4px category strip at the left edge,
 * a mono chain-number (top-left), the centered bold module name, and an LED
 * dot at the right (category color when engaged, warm-grey when bypassed).
 * When `selected`, the row gets a faint category-tinted background and the
 * name takes the category color.
 */
function ModuleTile({
  index,
  name,
  category = "var(--accent-primary)",
  active = true,
  selected = false,
  onClick,
  className = "",
  ...rest
}) {
  const num = index != null ? String(index).padStart(2, "0") : "";
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: `aa-module-tile ${selected ? "is-selected" : ""} ${className}`,
    onClick: onClick,
    style: {
      position: "relative",
      display: "block",
      width: "100%",
      height: "var(--h-tile)",
      padding: 0,
      background: "transparent",
      border: "none",
      borderBottom: "1px solid rgba(178,173,161,0.5)",
      cursor: "pointer",
      transition: "background var(--dur-fast) var(--ease-standard)"
    }
  }, rest), selected ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      left: "4px",
      top: 0,
      right: 0,
      bottom: 0,
      background: category,
      opacity: 0.14
    }
  }) : null, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      bottom: 0,
      width: "4px",
      background: category
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: "9px",
      top: "4px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--fs-8)",
      color: "var(--text-muted)",
      opacity: 0.7
    }
  }, num), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: "10px",
      right: "16px",
      top: 0,
      bottom: 0,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: "var(--fs-10)",
      fontWeight: "var(--fw-bold)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: selected ? category : "var(--text-body)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      right: "8px",
      top: "50%",
      transform: "translateY(-50%)",
      width: "6.4px",
      height: "6.4px",
      borderRadius: "var(--radius-pill)",
      background: active ? category : "var(--state-inactive)"
    }
  }));
}
Object.assign(__ds_scope, { ModuleTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/ModuleTile.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Knob = __ds_scope.Knob;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.ToggleSwitch = __ds_scope.ToggleSwitch;

__ds_ns.CRTDisplay = __ds_scope.CRTDisplay;

__ds_ns.EQCurve = __ds_scope.EQCurve;

__ds_ns.Meter = __ds_scope.Meter;

__ds_ns.ModMatrix = __ds_scope.ModMatrix;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.ModuleTile = __ds_scope.ModuleTile;

})();
